Something is hidden in this picture, I'm pretty sure of this... But what ?
